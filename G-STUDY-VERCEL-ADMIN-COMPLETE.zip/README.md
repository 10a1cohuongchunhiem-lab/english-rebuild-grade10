# G-STUDY – Student Website + Admin Control Center (Vercel)

## Included files

- `app.py`: Flask WSGI application and API backend. Exports the top-level `app` object required by Vercel.
- `server.py`: compatibility alias that also exports the same top-level `app` object (addresses deployments that detect `server.py`).
- `index.html`: student-facing learning website.
- `admin.html`: private Admin Control Center at `/admin`.
- `requirements.txt`: Flask and PostgreSQL driver.
- `vercel.json`: Vercel Python Function settings.
- `.env.example`: names of required environment variables, with placeholders only.

## Upload into the existing GitHub repository

1. Download and extract this ZIP.
2. Open the GitHub repository connected to the Vercel project `g-study-gmov`.
3. Upload the files from the extracted folder into the repository **root** (not inside an extra nested folder). The root must contain `app.py`, `server.py`, `index.html`, `admin.html`, `requirements.txt`, and `vercel.json`.
4. Overwrite the existing `admin.html`, `app.py`, `server.py`, `requirements.txt`, and `vercel.json` when asked.
5. Commit the upload to the branch connected to Vercel (usually `main`).
6. In Vercel, confirm the project is linked to that same repository and that Root Directory is `./`.

## Required Vercel Environment Variables

Open Project → Settings → Environment Variables. Add values for the **Production** environment:

- `DATABASE_URL`: connection string for a PostgreSQL database (for example Neon). Use the provider's pooled or regular Postgres URL as appropriate and keep SSL enabled.
- `ADMIN_EMAIL`: admin email address. If omitted, the code uses `admin@lingo10.vn`.
- `ADMIN_PASSWORD`: the secret used by the password-only admin login page. Set it in Vercel only; do not write it into source files or commit it to GitHub.

After saving variables, redeploy the latest Production deployment. Without a working `DATABASE_URL`, sign-in and persistent student records will not work on Vercel.

## Admin address

`https://YOUR-VERCEL-DOMAIN/admin`

Example for the current project: `https://g-study-gmov.vercel.app/admin`

The page initially shows only the G-STUDY internal portal label, a password box, and a submit button. After login it checks `/api/me` for a server-authenticated admin session. All admin data endpoints require the `admin` role on the server.

## Admin features

- Overview: registered student count, attempt count, active students in the last 7 days, and system average score.
- Students: search registered students, view attempt counts and average scores, export CSV.
- Learning content: create, edit and delete lessons; open a lesson to create, edit or delete its modules and activities.
- Results: view/search the 200 latest learning attempts and export CSV.
- Support inbox: read student support messages and mark them as processed.

Student account listing is currently read-only; the existing backend does not expose account deletion or account-role editing from the admin UI.

## Important

This admin page uses the existing authenticated API in `app.py`. Uploading only `admin.html` is not enough unless the same deployed app has the corresponding `/api/admin/...` routes and PostgreSQL connection configured.
