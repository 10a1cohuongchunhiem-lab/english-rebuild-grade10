# G-Study – English 10 Learning Platform

G-Study là ứng dụng học tiếng Anh 10 dùng Python + SQLite. Bản này có giao diện học sinh 4 tab và cổng quản trị tập trung.

## 1. Chạy trên máy tính

Yêu cầu Python 3.10 trở lên. Không cần cài thư viện ngoài.

```bash
python server.py
```

Mở `http://localhost:8090`; khu vực quản trị ở `http://localhost:8090/admin`.

## 2. Triển khai trên Vercel (đã bổ sung WSGI entry point)

Lỗi `PYTHON_ENTRYPOINT_NOT_FOUND` xảy ra do Vercel tìm thấy `server.py` nhưng ứng dụng cũ chỉ khởi chạy `ThreadingHTTPServer` ở trong `if __name__ == '__main__'`; nó chưa xuất một WSGI/ASGI application để Vercel gọi. Bản sửa này giữ nguyên các route/API hiện tại và thêm biến WSGI cấp cao nhất `app` trong `server.py`.

Các bước:

1. Giải nén gói dự án và thay các file trong repository GitHub bằng phiên bản mới, tối thiểu gồm `server.py`, `vercel.json`, `.python-version`, `requirements.txt`, `index.html` và `english10.db`.
2. Đảm bảo `server.py`, `index.html` và `english10.db` nằm ngay trong **Root Directory** mà dự án Vercel đang dùng. Nếu repository có thư mục con chứa ứng dụng, hãy đặt Root Directory đúng vào thư mục đó.
3. Trong Vercel → **Settings → Build & Development Settings**, không đặt Build Command hoặc Output Directory override tùy chỉnh; để Vercel tự nhận dạng Python từ `server.py`.
4. Commit/push các file đã thay lên nhánh đang kết nối với Vercel (ảnh lỗi cho thấy dự án đang lấy nhánh `main`) để kích hoạt deployment mới.
5. Sau khi triển khai, kiểm tra lần lượt `/`, `/admin` và `/api/public-settings`. API công khai cuối cùng phải trả JSON có `app_name` và `contact_phone`.

Không cần khai báo `app` thủ công trong Vercel dashboard: nó đã được export trong `server.py`.

### Cảnh báo quan trọng về dữ liệu trên Vercel

Ứng dụng hiện dùng SQLite. Vercel Functions không cung cấp ổ đĩa ghi bền vững cho database SQLite: bản sửa tự sao chép `english10.db` sang `/tmp` để function có thể khởi động và ghi dữ liệu trong một instance đang chạy. Tuy nhiên `/tmp` là vùng tạm theo instance; dữ liệu đăng ký, tiến độ học, đánh giá và chỉnh sửa admin **có thể mất hoặc không đồng bộ** khi function khởi động lại hay chạy trên instance khác.

Vì vậy cấu hình này sửa lỗi entry point và giúp kiểm tra ứng dụng trên Vercel, nhưng chưa phải cấu hình lưu dữ liệu production an toàn. Để dùng thật cho học sinh, cần chuyển database sang PostgreSQL/Neon/Supabase và cấu hình `DATABASE_URL` cùng phần chuyển đổi database, hoặc triển khai nguyên ứng dụng Python + SQLite trên Render với Persistent Disk (đã có `render.yaml`). Không đặt `DB_PATH` trỏ vào thư mục mã nguồn trên Vercel vì thư mục đó không ghi được.

## 3. Triển khai trên Render (lưu SQLite bền vững)

1. Đưa thư mục dự án lên GitHub.
2. Tạo Web Service/Blueprint từ repository và dùng `render.yaml`.
3. Đảm bảo Persistent Disk được gắn tại `/var/data`.
4. Biến `DB_PATH` được cấu hình thành `/var/data/english10.db`; lần chạy đầu sẽ sao chép DB ban đầu vào ổ đĩa nếu chưa tồn tại.

Đây là lựa chọn phù hợp hơn để chạy bản SQLite hiện tại mà không phải viết lại lớp database.

## 4. Quản trị và bảo mật

- Email quản trị mặc định: `admin@lingo10.vn`.
- Dùng mật khẩu quản trị đã được thiết lập trong cơ sở dữ liệu hiện tại; không đặt mật khẩu trong HTML hoặc repository công khai.
- Đường dẫn admin: `/admin`.
- Nên dùng HTTPS và đổi mật khẩu quản trị sau khi xác nhận đăng nhập.

Các biến môi trường hỗ trợ:

| Biến | Ý nghĩa |
|---|---|
| `PORT` | Cổng chạy local/Render, mặc định `8090` |
| `DB_PATH` | Đường dẫn SQLite; dùng `/var/data/english10.db` trên Render có disk |
| `ADMIN_EMAIL` | Email admin, mặc định `admin@lingo10.vn` |
| `ADMIN_PASSWORD` | Mật khẩu bootstrap khi tạo DB mới |
| `RESET_ADMIN_PASSWORD` | Đặt `1` cùng `ADMIN_PASSWORD` để xoay mật khẩu admin khi khởi động; bỏ biến sau khi đổi |

## 5. Chức năng chính

### Ứng dụng học sinh
- Thanh điều hướng điện thoại: **Trang chủ, Lộ trình, Thống kê, Cá nhân**.
- Trang chủ: tiếp tục học, tổng quan, nội dung hôm nay và tiến độ gần đây.
- Lộ trình: Unit, kỹ năng và trạng thái hoàn thành.
- Thống kê: điểm, lượt học, thời gian và tiến độ theo Unit.
- Cá nhân: đổi mật khẩu, liên hệ admin, gửi đánh giá và đường dẫn admin.

### Web Admin `/admin`
- Tổng quan hệ thống.
- Quản lý tài khoản học sinh, khóa/mở khóa và đặt mật khẩu tạm.
- Quản lý Unit, kỹ năng và câu hỏi.
- Theo dõi lịch sử học.
- Xem đánh giá/góp ý.
- Cài đặt tên ứng dụng, liên hệ, mục tiêu tuần và trạng thái đăng ký.
